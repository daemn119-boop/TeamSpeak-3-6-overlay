'use strict';
const { app, BrowserWindow, Tray, Menu, globalShortcut, ipcMain, screen, safeStorage, nativeImage, clipboard } = require('electron');
const fs = require('fs'), path = require('path');
const { TsClient } = require('./ts');
const { Ts3Client } = require('./ts3');
app.disableHardwareAcceleration();
if (!app.requestSingleInstanceLock()) app.quit();

const DEF = { port: 5899, ts3Port: 25639, clientMode: 'auto', ts3Key: '', nickColor: '#ffffff', talkColor: '#3ddc84', bgColor: '#000000', bgOpacity: 0.55,
  font: 'Montserrat', fontSize: 15, bold: true, plateWidth: 0, radius: 20, padX: 12, padY: 5, gap: 10,
  anchor: 'tl', x: 20, y: 20, mode: 'talking', showConnected: true, settingsVersion: 8, animation: 'fade', animationDuration: 120, locked: true, visible: true, hotkey: 'Ctrl+Shift+F9', autostart: false, welcomeDone: false, key: '' };
const TXT = { connecting: 'Подключение…', waiting: 'Ожидание разрешения — подтвердите запрос в TeamSpeak',
  nocon: 'Нет соединения с TeamSpeak (клиент запущен? Remote Apps включены? порт верный?)',
  denied: 'Доступ не выдан — разрешите приложение в TeamSpeak (Настройки → Remote Apps)',
  novoice: 'Не подключён голосовой канал', ok: 'Подключено' };

let S = { ...DEF }, ov, win, wel, testing = null, tray, ts, ts3, snap = { status: 'connecting', members: [] }, snap6 = { status: 'connecting', members: [] }, snap3 = { status: 'connecting', members: [] }, memKey = '', memTs3Key = '', saveT, hotkeyOk = true, lastSig = '';
const file = () => path.join(app.getPath('userData'), 'settings.json');
const load = () => { try {
  const saved = JSON.parse(fs.readFileSync(file(), 'utf8'));
  S = { ...DEF, ...saved };
  if (saved.settingsVersion !== 8) {
    if (!saved.settingsVersion) { S.mode = 'talking'; S.font = 'Montserrat'; }
    if (saved.settingsVersion < 7 && saved.animation === 'none') S.animation = 'fade';
    if (saved.settingsVersion < 8 && saved.locked === false) S.locked = true;
    if (saved.radius === 8) S.radius = 20;
    if (saved.padY === 6) S.padY = 5;
    if (saved.gap === 4) S.gap = 10;
    if (saved.fontSize === 18) S.fontSize = 15;
    if (saved.settingsVersion === 3 && saved.animation === 'fade' && saved.animationDuration === 180) S.animation = 'none';
    if (saved.animationDuration === 180 || saved.animationDuration === 320) S.animationDuration = 120;
    S.settingsVersion = 8; saveNow();
  }
} catch {} };
const saveNow = () => { clearTimeout(saveT); try { fs.mkdirSync(path.dirname(file()), { recursive: true }); fs.writeFileSync(file(), JSON.stringify(S, null, 2)); return true; } catch (e) { console.error('Не удалось сохранить настройки:', e); return false; } };
const save = () => { clearTimeout(saveT); saveT = setTimeout(saveNow, 300); };
const pub = () => { const { key, ts3Key, ...r } = S; return { ...r, ts3KeySet: !!getTs3Key() }; };
// API-ключ хранится только зашифрованным (Windows DPAPI через safeStorage); если шифрование недоступно — только в памяти
const getKey = () => { try { return S.key && safeStorage.isEncryptionAvailable() ? safeStorage.decryptString(Buffer.from(S.key, 'base64')) : memKey; } catch { return ''; } };
const setKey = (v) => { memKey = v; S.key = v && safeStorage.isEncryptionAvailable() ? safeStorage.encryptString(v).toString('base64') : ''; save(); };
const getTs3Key = () => { try { return S.ts3Key && safeStorage.isEncryptionAvailable() ? safeStorage.decryptString(Buffer.from(S.ts3Key, 'base64')) : memTs3Key; } catch { return ''; } };
const setTs3Key = (v) => { memTs3Key = v; S.ts3Key = v && safeStorage.isEncryptionAvailable() ? safeStorage.encryptString(v).toString('base64') : ''; saveNow(); if (ts3) { ts3.configure(S.ts3Port, getTs3Key()); ts3.reconnect(); } pushSettings(); };
const selectState = () => {
  if (S.clientMode === 'ts6') return snap6;
  if (S.clientMode === 'ts3') return snap3;
  if (['ok', 'novoice'].includes(snap6.status)) return snap6;
  if (['ok', 'novoice'].includes(snap3.status)) return snap3;
  if (snap6.status === 'waiting' || snap3.status === 'waiting') return snap6.status === 'waiting' ? snap6 : snap3;
  if (snap6.status === 'denied' || snap3.status === 'denied') return snap6.status === 'denied' ? snap6 : snap3;
  if (snap6.status === 'connecting' || snap3.status === 'connecting') return { status: 'connecting', members: [] };
  return snap6;
};
const applyClientMode = () => {
  const use6 = S.clientMode !== 'ts3', use3 = S.clientMode !== 'ts6';
  for (const [client, use] of [[ts, use6], [ts3, use3]]) if (client) {
    if (use && client.stopped) client.start();
    else if (!use && !client.stopped) client.stop();
  }
};
const st = () => {
  const message = snap.status === 'nocon' && snap.client === 'ts3' ? 'Нет соединения с TeamSpeak 3 ClientQuery (проверьте, что TS3 запущен и ClientQuery включён)'
    : snap.status === 'waiting' && snap.client === 'ts3' ? 'Установлено соединение с TeamSpeak 3 ClientQuery'
    : snap.status === 'denied' && snap.client === 'ts3' ? 'TeamSpeak 3 отклонил ClientQuery — проверьте API-ключ и разрешение доступа'
      : TXT[snap.status];
  return { ...snap, text: message + (snap.status === 'ok' ? ` · в канале: ${snap.members.length}` : '') };
};
// Keep one speaker active while toggling another to demonstrate simultaneous voices.
const TEST = (t) => ({ status: 'ok', text: 'Тестовый оверлей', members: [{ id: 1, nick: 'Игрок 1', talk: false }, { id: 2, nick: 'Игрок 2', talk: true }, { id: 3, nick: 'Игрок 3', talk: t }] });
let lastSentState = '';
const push = () => {
  const state = testing ? TEST(testing.t) : st();
  const serialized = JSON.stringify(state);
  if (ov && !ov.isDestroyed() && serialized !== lastSentState) {
    lastSentState = serialized;
    ov.webContents.send('state', state);
  }
  if (win && !win.isDestroyed()) win.webContents.send('state', st());
};
function startTest() { // временно показать пример поверх рабочего стола (8 с), потом вернуть как было
  if (testing) { clearInterval(testing.i); clearTimeout(testing.o); }
  ov.showInactive(); testing = { t: false }; push();
  testing.i = setInterval(() => { testing.t = !testing.t; push(); }, 700);
  testing.o = setTimeout(() => { clearInterval(testing.i); testing = null; if (!S.visible) ov.hide(); push(); }, 8000);
}
const pushSettings = () => { for (const w of [ov, win]) if (w && !w.isDestroyed()) w.webContents.send('settings', pub()); };

function place() {
  if (!ov || ov.isDestroyed()) return;
  const [w, h] = ov.getSize(), M = 20; let x, y;
  if (S.anchor === 'custom') {
    const b = screen.getDisplayMatching({ x: S.x, y: S.y, width: w, height: h }).workArea;
    x = Math.min(Math.max(S.x, b.x), b.x + b.width - w); y = Math.min(Math.max(S.y, b.y), b.y + b.height - h);
  } else {
    const b = screen.getPrimaryDisplay().workArea;
    x = S.anchor.includes('r') ? b.x + b.width - w - M : b.x + M; y = S.anchor.includes('b') ? b.y + b.height - h - M : b.y + M;
  }
  ov.setPosition(Math.round(x), Math.round(y));
}
const applyLock = () => { ov.setIgnoreMouseEvents(!!S.locked); ov.setFocusable(!S.locked); };
const applyVisible = () => (S.visible ? ov.showInactive() : ov.hide());
const toggleVisible = () => { S.visible = !S.visible; applyVisible(); save(); menu(); pushSettings(); };

function createOverlay() {
  ov = new BrowserWindow({ width: 300, height: 60, transparent: true, frame: false, resizable: false, skipTaskbar: true, hasShadow: false,
    focusable: !S.locked, alwaysOnTop: true, show: false, webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true } });
  ov.setAlwaysOnTop(true, 'screen-saver'); // поверх безрамочных игр; игру не трогаем (без инжекта)
  ov.loadFile('overlay.html'); applyLock(); place();
  ov.on('moved', () => { const [x, y] = ov.getPosition(); Object.assign(S, { x, y, anchor: 'custom' }); save(); pushSettings(); });
  ov.once('ready-to-show', applyVisible);
  // Windows может сбросить/перебить topmost (другое topmost-окно, смена фокуса, блокировка, сон, смена мониторов) —
  // периодически подтверждаем флаг и поднимаем окно наверх своей группы, не забирая фокус.
  const raise = () => {
    if (!ov || ov.isDestroyed() || !ov.isVisible()) return;
    if (!ov.isAlwaysOnTop()) ov.setAlwaysOnTop(true, 'screen-saver');
    ov.moveTop();
  };
  setInterval(raise, 2000);
  const { powerMonitor } = require('electron');
  const reassert = () => { if (!ov || ov.isDestroyed()) return; ov.setAlwaysOnTop(false); ov.setAlwaysOnTop(true, 'screen-saver'); place(); raise(); };
  for (const e of ['resume', 'unlock-screen']) powerMonitor.on(e, () => setTimeout(reassert, 1000));
  for (const e of ['display-added', 'display-removed', 'display-metrics-changed']) screen.on(e, () => setTimeout(reassert, 500));
}
function openSettings() {
  if (win && !win.isDestroyed()) return win.show();
  win = new BrowserWindow({ width: 1228, height: 729, minWidth: 560, minHeight: 440, title: 'TS6 Overlay — настройки', autoHideMenuBar: true, backgroundColor: '#14171c',
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true } });
  win.setMenu(null); win.loadFile('settings.html'); win.on('closed', () => (win = null));
}
function openWelcome() {
  if (wel && !wel.isDestroyed()) return wel.show();
  wel = new BrowserWindow({ width: 780, height: 680, minWidth: 520, minHeight: 480, title: 'TS6 Overlay — первый запуск', autoHideMenuBar: true, backgroundColor: '#14171c',
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true } });
  wel.setMenu(null); wel.loadFile('welcome.html'); wel.on('closed', () => (wel = null));
}
function hotkey() {
  globalShortcut.unregisterAll(); hotkeyOk = true;
  if (S.hotkey) { try { hotkeyOk = globalShortcut.register(S.hotkey, toggleVisible); } catch { hotkeyOk = false; } }
}
const icon = (r, g, b) => { const s = 16, buf = Buffer.alloc(s * s * 4);
  for (let y = 0; y < s; y++) for (let x = 0; x < s; x++) if (Math.hypot(x - 7.5, y - 7.5) < 7) { const o = (y * s + x) * 4; buf[o] = b; buf[o + 1] = g; buf[o + 2] = r; buf[o + 3] = 255; }
  return nativeImage.createFromBitmap(buf, { width: s, height: s }); };
let icons;
function menu() {
  if (!tray) return;
  tray.setImage(snap.status === 'ok' ? icons.ok : snap.status === 'waiting' ? icons.wait : icons.off);
  tray.setToolTip('TS6 Overlay — ' + st().text);
  tray.setContextMenu(Menu.buildFromTemplate([
    { label: st().text, enabled: false }, { type: 'separator' },
    { label: 'Показывать оверлей', type: 'checkbox', checked: S.visible, click: toggleVisible },
    { label: 'Заблокировать положение (клики насквозь)', type: 'checkbox', checked: S.locked, click: (i) => { S.locked = i.checked; applyLock(); save(); pushSettings(); } },
    { label: 'Настройки…', click: openSettings }, { type: 'separator' }, { label: 'Выход', click: () => app.quit() }]));
}

ipcMain.handle('init', () => ({ s: pub(), st: st(), hotkeyOk }));
ipcMain.on('set-ts3-key', (_e, value) => { setTs3Key(String(value || '').trim()); });
ipcMain.handle('paste-ts3-key', () => { const value = clipboard.readText().trim(); if (!value) return false; setTs3Key(value); return true; });
ipcMain.handle('size', (_e, w, h) => {
  if (!ov || ov.isDestroyed()) return false;
  const size = [Math.max(1, Math.ceil(w)), Math.max(1, Math.ceil(h))], current = ov.getContentSize();
  if (current[0] !== size[0] || current[1] !== size[1]) { ov.setContentSize(size[0], size[1]); place(); }
  return true;
});
ipcMain.on('test', startTest);
ipcMain.handle('save', () => saveNow());
ipcMain.on('welcome-done', () => { S.welcomeDone = true; saveNow(); if (wel) wel.close(); openSettings(); });
ipcMain.handle('reset', () => {
  const old = { ...S }; S = { ...DEF, key: S.key, ts3Key: S.ts3Key, welcomeDone: true };
  if (S.port !== old.port) ts.setPort(S.port);
  ts3.configure(S.ts3Port, getTs3Key()); applyClientMode(); snap = selectState();
  hotkey(); app.setLoginItemSettings({ openAtLogin: false }); applyLock(); applyVisible(); place(); saveNow(); menu(); pushSettings();
  return { hotkeyOk };
});
ipcMain.handle('set', (_e, p) => {
  const old = { ...S };
  for (const k in p) if (k in DEF && k !== 'key' && k !== 'ts3Key') S[k] = p[k];
  if (!(S.port >= 1 && S.port <= 65535)) S.port = old.port;
  if (S.port !== old.port) ts.setPort(S.port);
  if (S.ts3Port !== old.ts3Port) ts3.configure(S.ts3Port, getTs3Key());
  if (S.clientMode !== old.clientMode) applyClientMode();
  snap = selectState();
  if ('hotkey' in p) hotkey();
  if ('autostart' in p) app.setLoginItemSettings({ openAtLogin: !!S.autostart });
  if ('locked' in p) applyLock();
  if ('visible' in p) applyVisible();
  if ('anchor' in p || 'x' in p) place();
  const saved = saveNow(); snap = selectState(); push(); menu(); pushSettings();
  if ('font' in p && S.font !== old.font && ov && !ov.isDestroyed()) ov.webContents.reload();
  return { hotkeyOk, saved };
});

app.whenReady().then(() => {
  // Migrate settings from the beta build, whose productName changed Electron's userData folder.
  const legacy = path.join(app.getPath('appData'), 'TS6 Overlay', 'settings.json');
  try {
    if (fs.existsSync(legacy)) {
      const current = file();
      if (!fs.existsSync(current) || fs.statSync(legacy).mtimeMs > fs.statSync(current).mtimeMs) {
        fs.mkdirSync(path.dirname(current), { recursive: true }); fs.copyFileSync(legacy, current);
      }
    }
  } catch (e) { console.error('Не удалось перенести настройки предыдущей версии:', e); }
  load();
  icons = { ok: icon(61, 220, 132), wait: icon(240, 180, 40), off: icon(140, 140, 140) };
  ts = new TsClient({ port: S.port, getKey, setKey });
  ts3 = new Ts3Client({ port: S.ts3Port, getKey: getTs3Key, setKey: (v) => { memTs3Key = v; S.ts3Key = v && safeStorage.isEncryptionAvailable() ? safeStorage.encryptString(v).toString('base64') : ''; save(); } });
  const updateState = () => { snap = selectState(); const sig = snap.status + snap.members.length; push(); if (sig !== lastSig) { lastSig = sig; menu(); } };
  ts.on('state', (s) => { snap6 = s; updateState(); });
  ts3.on('state', (s) => { snap3 = s; updateState(); });
  ts3.on('warn', (e) => console.warn('TeamSpeak 3 ClientQuery:', e.message));
  createOverlay(); tray = new Tray(icons.off); tray.on('double-click', openSettings); menu(); hotkey();
  app.setLoginItemSettings({ openAtLogin: !!S.autostart });
  applyClientMode(); if (!S.welcomeDone) openWelcome(); // дальше запуск сразу в трей
});
app.on('second-instance', () => (S.welcomeDone ? openSettings() : openWelcome()));
app.on('window-all-closed', () => {}); // живём в трее
app.on('will-quit', () => globalShortcut.unregisterAll());