'use strict';
const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('api', {
  on: (ch, cb) => ipcRenderer.on(ch, (_e, d) => cb(d)),
  init: () => ipcRenderer.invoke('init'),
  size: (w, h) => ipcRenderer.invoke('size', w, h),
  set: (p) => ipcRenderer.invoke('set', p),
  setTs3Key: (key) => ipcRenderer.send('set-ts3-key', key),
  pasteTs3Key: () => ipcRenderer.invoke('paste-ts3-key'),
  save: () => ipcRenderer.invoke('save'),
  reset: () => ipcRenderer.invoke('reset'),
  test: () => ipcRenderer.send('test'),
  welcomeDone: () => ipcRenderer.send('welcome-done'),
});
