'use strict';
// Тест Remote Apps на поддельном HTTP/WebSocket-сервере (без TeamSpeak и Windows).
const assert = require('assert');
const http = require('http');
const WebSocket = require('faye-websocket');
const { TsClient } = require('../ts');
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
(async () => {
  const server = http.createServer(); let key = '', sock, got, connections = 0;
  server.on('upgrade', (req, socket, body) => {
    if (!WebSocket.isWebSocket(req)) return socket.destroy();
    const ws = new WebSocket(req, socket, body); connections++;
    ws.on('message', (event) => {
      got = JSON.parse(event.data);
      if (connections === 1) sock = ws;
      else ws.close(); // reject reconnect to test the denied state
    });
  });
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  const c = new TsClient({ port: server.address().port, retryMs: 100, getKey: () => key, setKey: (v) => (key = v) });
  let last; c.on('state', (s) => { last = s; });
  c.start(); await sleep(150);
  assert.equal(last.status, 'waiting'); assert.equal(got.type, 'auth'); assert.equal(got.payload.content.apiKey, '');
  const P = (nickname) => ({ nickname });
  sock.send(JSON.stringify({ type: 'auth', payload: { apiKey: 'K1', connections: [{ id: 1, clientId: 10, clientInfos: [
    { id: 10, channelId: 5, properties: P('Me') }, { id: 11, channelId: 5, properties: P('Anna') }, { id: 12, channelId: 6, properties: P('Other') }] }] } }));
  await sleep(40); assert.equal(key, 'K1'); assert.equal(last.status, 'ok');
  assert.deepEqual(last.members.map((m) => m.nick), ['Anna', 'Me']);
  const send = (o) => sock.send(JSON.stringify(o));
  send({ type: 'talkStatusChanged', payload: { connectionId: 1, clientId: 11, status: 1 } }); await sleep(20);
  assert.equal(last.members.find((m) => m.nick === 'Anna').talk, true);
  send({ type: 'talkStatusChanged', payload: { connectionId: 1, clientId: 11, status: 0 } }); await sleep(20);
  assert.equal(last.members.find((m) => m.nick === 'Anna').talk, false);
  send({ type: 'clientMoved', payload: { connectionId: 1, clientId: 12, newChannelId: 5, properties: P('Other') } }); await sleep(20);
  assert.equal(last.members.length, 3);
  send({ type: 'clientMoved', payload: { connectionId: 1, clientId: 11, newChannelId: 0, properties: P('Anna') } }); await sleep(20);
  assert.deepEqual(last.members.map((m) => m.nick), ['Me', 'Other']);
  send({ type: 'clientMoved', payload: { connectionId: 1, clientId: 10, newChannelId: 6, properties: P('Me') } }); await sleep(20);
  assert.deepEqual(last.members.map((m) => m.nick), ['Me']);
  send({ type: 'clientPropertiesUpdated', payload: { connectionId: 1, clientId: 10, properties: P('Me2') } }); await sleep(20);
  assert.equal(last.members[0].nick, 'Me2');
  send({ type: 'connectStatusChanged', payload: { connectionId: 1, status: 0 } }); await sleep(20);
  assert.equal(last.status, 'novoice');
  sock.close(); await sleep(50); assert.equal(last.status, 'nocon');
  await sleep(200); assert.equal(got.payload.content.apiKey, 'K1');
  await sleep(40); assert.equal(last.status, 'denied');
  c.stop(); await new Promise((resolve) => server.close(resolve));
  console.log('OK: TeamSpeak 6 Remote Apps protocol, state and reconnect');
})().catch((e) => { console.error(e); process.exit(1); });
