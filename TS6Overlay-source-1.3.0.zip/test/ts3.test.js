'use strict';
// Fake ClientQuery server: validates CRLF-inverted line endings, channel selection, voice flags and command serialization.
const assert = require('assert');
const net = require('net');
const { Ts3Client } = require('../ts3');
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
async function until(fn, timeout = 2500) {
  const end = Date.now() + timeout;
  while (Date.now() < end) { if (fn()) return; await sleep(10); }
  throw new Error('Timed out waiting for ClientQuery state');
}

(async () => {
  let selected = '7', hasVoiceServer = true;
  const commands = [];
  const server = net.createServer((socket) => {
    server._testSocket = socket;
    socket.setEncoding('utf8');
    socket.write('TS3 Client\n\rWelcome to ClientQuery\n\rUse the "auth" command to authenticate\n\rselected schandlerid=7\n\r');
    let buffer = '';
    socket.on('data', (chunk) => {
      buffer += chunk;
      let i;
      while ((i = buffer.indexOf('\n')) >= 0) {
        const line = buffer.slice(0, i).replace(/^\r+|\r+$/g, ''); buffer = buffer.slice(i + 1);
        if (!line) continue;
        commands.push(line);
        if (line.startsWith('use schandlerid=')) selected = line.slice('use schandlerid='.length);
        if (line === 'whoami' && !hasVoiceServer) {
          socket.write('error id=1794 msg=not\sconnected\sto\sserver\n\r');
        } else if (line === 'whoami') {
          const cid = selected === '8' ? '9' : '5';
          socket.write(`client_id=42 client_channel_id=${cid}\n\rerror id=0 msg=ok\n\r`);
        } else if (line === 'clientlist -voice') {
          const cid = selected === '8' ? '9' : '5';
          socket.write(`clid=42 cid=${cid} client_type=0 client_nickname=Me client_is_talker=1 client_flag_talking=0|clid=43 cid=${cid} client_type=0 client_nickname=Anna client_is_talker=1 client_flag_talking=0\n\rerror id=0 msg=ok\n\r`);
        } else {
          socket.write('error id=0 msg=ok\n\r');
          if (line.endsWith('event=notifyclientmoved')) socket.write(`notifyclientmoved schandlerid=${selected} clid=43\n\r`);
        }
      }
    });
  });
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  const client = new Ts3Client({ port: server.address().port, getKey: () => 'test-key', setKey: () => {} });
  const warnings = []; let last;
  client.on('state', (state) => { last = state; }); client.on('warn', (e) => warnings.push(e));
  client.start();
  await until(() => last && last.status === 'ok');
  assert.equal(last.members.length, 2);
  assert.ok(commands.includes('use schandlerid=7'), 'bootstrap must select the greeting handler');
  assert.ok(commands.includes('auth apikey=test-key'));
  assert.equal(last.members.find((x) => x.nick === 'Anna').talk, false, 'talk power is not active speech');
  assert.equal(warnings.some((e) => /Предыдущая команда/.test(e.message)), false, 'notifications must queue behind commands');

  // Drive handler and server-state changes through the fake ClientQuery socket.
  await until(() => commands.includes('clientlist -voice'));
  hasVoiceServer = false;
  const serverSocket = server._testSocket;
  serverSocket.write('notifycurrentserverconnectionchanged schandlerid=7\n\r');
  await until(() => last.status === 'novoice');
  hasVoiceServer = true;
  serverSocket.write('notifycurrentserverconnectionchanged schandlerid=8\n\r');
  await until(() => last.status === 'ok' && commands.includes('use schandlerid=8'));
  serverSocket.write('notifytalkstatuschange schandlerid=7 status=1 clid=43\n\r');
  await sleep(30);
  assert.equal(last.members.find((x) => x.nick === 'Anna').talk, false, 'ignore talk events from other handlers');
  serverSocket.write('notifytalkstatuschange schandlerid=8 status=1 clid=43\n\r');
  await until(() => last.members.find((x) => x.nick === 'Anna').talk === true);

  client.stop(); await new Promise((resolve) => server.close(resolve));
  console.log('OK: TS3 ClientQuery line endings, server/channel state, speech flags, handler selection and command queue');
})().catch((e) => { console.error(e); process.exit(1); });
