'use strict';
(function (g) {
  const rgba = (h, a) => { const n = parseInt(h.slice(1), 16); return 'rgba(' + (n >> 16 & 255) + ',' + (n >> 8 & 255) + ',' + (n & 255) + ',' + a + ')'; };
  g.renderPlates = function (box, S, items, onResize) {
    const effect = S.animation || 'none';
    const duration = effect === 'none' ? 0 : Math.max(0, Number(S.animationDuration ?? 180) || 0);
    const transition = 'opacity ' + duration + 'ms ease, transform ' + duration + 'ms ease';
    const activeKeys = new Set(items.map((i) => String(i.key ?? i.id ?? i.t)));
    const resize = () => typeof onResize === 'function' ? onResize() : undefined;
    const enteringNodes = [];
    box.style.gap = S.gap + 'px';

    for (const node of [...box.children]) {
      if (!activeKeys.has(node.dataset.key) && node.dataset.leaving !== '1') {
        if (!duration) { node.remove(); continue; }
        node.dataset.leaving = '1';
        node.style.transition = transition;
        requestAnimationFrame(() => {
          if (node.dataset.leaving !== '1') return;
          node.style.opacity = '0';
          node.style.transform = effect === 'slide' ? 'translateY(-6px)' : 'none';
        });
        node.__removeTimer = setTimeout(() => {
          if (node.dataset.leaving === '1') { node.remove(); resize(); }
        }, duration + 30);
      }
    }

    for (let itemIndex = 0; itemIndex < items.length; itemIndex++) {
      const item = items[itemIndex];
      const key = String(item.key ?? item.id ?? item.t);
      let node = [...box.children].find((n) => n.dataset.key === key);
      const entering = !node;
      if (!node) { node = document.createElement('div'); node.className = 'p'; node.dataset.key = key; }
      if (node.dataset.leaving === '1') {
        clearTimeout(node.__removeTimer);
        node.dataset.leaving = '0';
      }
      node.textContent = item.t;
      Object.assign(node.style, {
        padding: S.padY + 'px ' + S.padX + 'px',
        borderRadius: S.radius + 'px',
        minWidth: S.plateWidth + 'px',
        fontFamily: '"' + S.font + '", sans-serif',
        fontSize: S.fontSize + 'px',
        fontWeight: S.font === 'Stiff Staff Heavy' ? '900' : '400',
        WebkitTextStroke: S.bold && S.font !== 'Stiff Staff Heavy' ? '0.25px currentColor' : '0px',
        background: rgba(S.bgColor, S.bgOpacity),
        color: item.talk ? S.talkColor : S.nickColor,
        boxShadow: item.talk ? '0 0 0 2px ' + S.talkColor + ', 0 0 10px ' + rgba(S.talkColor, .7) : 'none',
        transition: duration ? transition : 'none'
      });
      if (entering && duration) {
        node.style.opacity = '0';
        node.style.transform = effect === 'slide' ? 'translateY(6px)' : 'none';
        enteringNodes.push(node);
      } else {
        node.style.opacity = '1';
        node.style.transform = 'none';
      }
      const at = box.children[itemIndex];
      if (at !== node) box.insertBefore(node, at || null);
    }

    if (enteringNodes.length) {
      for (const node of enteringNodes) void node.offsetWidth;
      Promise.resolve(resize()).catch(() => {}).then(() => {
        requestAnimationFrame(() => requestAnimationFrame(() => {
          for (const node of enteringNodes) {
            if (node.isConnected && node.dataset.leaving !== '1') {
              node.style.opacity = '1';
              node.style.transform = 'none';
            }
          }
        }));
      });
    } else resize();

    if (typeof onResize === 'function') {
      clearTimeout(box.__finalResizeTimer);
      box.__finalResizeTimer = setTimeout(resize, duration + 50);
    }
  };
})(window);
