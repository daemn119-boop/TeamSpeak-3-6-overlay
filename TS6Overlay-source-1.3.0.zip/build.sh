#!/bin/sh
# Сборка Windows x64 (можно запускать и на Linux/macOS): sh build.sh
set -e
S=$(mktemp -d); cp -r main.js preload.js ts.js ts3.js render.js overlay.html settings.html welcome.html assets package.json "$S"/
(cd "$S" && node -e "const p=require('./package.json');delete p.devDependencies;delete p.scripts;require('fs').writeFileSync('package.json',JSON.stringify(p,null,2))" && npm install --omit=dev --no-audit --no-fund --ignore-scripts)
V=$(node -p "require('./package.json').devDependencies.electron.replace('^','')")
npx electron-packager "$S" TS6Overlay --platform=win32 --arch=x64 --electron-version="$V" --app-version=1.3.0 --build-version=1.3.0.0 --app-copyright="Copyright 2026 lvloJlb (Дмитрий). Эксклюзивно для клана Funny Company." --win32metadata.CompanyName="lvloJlb (Дмитрий)" --win32metadata.FileDescription="TS6 Overlay — оверлей говорящих пользователей TeamSpeak 6 и 3" --win32metadata.ProductName="TS6 Overlay" --win32metadata.InternalName="TS6Overlay" --win32metadata.OriginalFilename="TS6Overlay.exe" --out=dist --overwrite

