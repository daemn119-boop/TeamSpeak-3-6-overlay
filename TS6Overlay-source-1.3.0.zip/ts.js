'use strict';
// Клиент TeamSpeak Remote Apps (WebSocket ws://127.0.0.1:<порт>). Без UI — можно тестировать отдельно.
const WebSocket = require('faye-websocket').Client;
const { EventEmitter } = require('events');
const APP = { identifier: 'local.ts6overlay', version: '1.3.0', name: 'TS6 Overlay', description: 'Shows who is talking in your voice channel' };
const k = (c, id) => c + ':' + id;

class TsClient extends EventEmitter {
  constructor(o) {
    super();
    this.o = { retryMs: 2000, ...o };
    this.port = o.port; this.stopped = true; this.phase = 'connecting'; this.fails = 0; this.clear();
  }
  clear() { this.conns = new Map(); this.clients = new Map(); this.active = null; }
  start() { this.stopped = false; this.connect(); }
  stop() { this.stopped = true; clearTimeout(this.timer); const w = this.ws; this.ws = null; if (w) { if (typeof w.terminate === 'function') w.terminate(); else w.close(); } }
  setPort(p) { this.port = p; if (!this.stopped) { this.stop(); this.start(); } }

  connect() {
    clearTimeout(this.timer); this.clear();
    if (this.phase !== 'nocon' && this.phase !== 'denied') { this.phase = 'connecting'; this.emit('state', this.snapshot()); }
    const ws = (this.ws = new WebSocket('ws://127.0.0.1:' + this.port));
    let opened = false, authed = false, sentKey = '';
    ws.on('open', () => {
      opened = true; sentKey = this.o.getKey() || '';
      this.phase = 'waiting'; this.emit('state', this.snapshot());
      ws.send(JSON.stringify({ type: 'auth', payload: { ...APP, content: { apiKey: sentKey } } }));
    });
    ws.on('message', (d) => {
      let m; try { m = JSON.parse(String(d && Object.prototype.hasOwnProperty.call(d, 'data') ? d.data : d)); } catch { return; }
      if (m.type === 'auth') authed = true;
      try { this.handle(m); } catch (e) { this.emit('warn', e); }
    });
    ws.on('error', () => {});
    ws.on('close', () => {
      if (this.ws !== ws) return;
      this.clear();
      if (!authed && opened && sentKey) this.o.setKey(''); // ключ отозван — запросим доступ заново
      this.phase = authed ? 'nocon' : opened ? 'denied' : 'nocon';
      if (this.phase === 'denied') this.fails++;
      this.emit('state', this.snapshot());
      // при отказе не заваливаем TeamSpeak запросами: пауза растёт до 30 с
      const delay = this.phase === 'denied' ? Math.min(30000, 5000 * 2 ** Math.min(this.fails - 1, 3)) : this.o.retryMs;
      if (!this.stopped) this.timer = setTimeout(() => this.connect(), delay);
    });
  }

  put(conn, id, ch, props) {
    const old = this.clients.get(k(conn, id));
    this.clients.set(k(conn, id), { id, conn, ch, nick: (props && props.nickname) || (old && old.nick) || '?', talk: old && old.ch === ch ? old.talk : false });
  }

  handle(m) {
    const p = m.payload || {};
    switch (m.type) {
      case 'auth':
        this.o.setKey(p.apiKey || ''); this.clear(); this.fails = 0;
        for (const c of p.connections || []) {
          this.conns.set(c.id, { id: c.id, clientId: c.clientId });
          for (const ci of c.clientInfos || []) this.put(c.id, ci.id, ci.channelId, ci.properties);
          if (this.active == null) this.active = c.id;
        }
        this.phase = 'online'; break;
      case 'clientMoved': { // вход/выход с сервера (oldChannelId/newChannelId = 0) и смена канала
        if (!p.newChannelId) this.clients.delete(k(p.connectionId, p.clientId));
        else {
          this.put(p.connectionId, p.clientId, p.newChannelId, p.properties);
          const c = this.conns.get(p.connectionId);
          if (c && c.clientId === p.clientId) this.active = c.id;
        }
        break;
      }
      case 'talkStatusChanged': { const c = this.clients.get(k(p.connectionId, p.clientId)); if (c) c.talk = p.status > 0; break; }
      case 'clientPropertiesUpdated': {
        const c = this.clients.get(k(p.connectionId, p.clientId));
        if (c && p.properties && p.properties.nickname) c.nick = p.properties.nickname; break;
      }
      case 'clientSelfPropertyUpdated': if (this.conns.has(p.connectionId)) this.active = p.connectionId; break;
      case 'connectStatusChanged':
        if (p.status === 0) {
          this.conns.delete(p.connectionId);
          for (const key of [...this.clients.keys()]) if (key.startsWith(p.connectionId + ':')) this.clients.delete(key);
          if (this.active === p.connectionId) this.active = null;
        } else if (p.status === 4) {
          this.conns.set(p.connectionId, { id: p.connectionId, clientId: p.info && p.info.clientId });
          if (this.active == null) this.active = p.connectionId;
        }
        break;
      default: return;
    }
    this.emit('state', this.snapshot());
  }

  snapshot() {
    let status = this.phase, members = [];
    if (this.phase === 'online') {
      status = 'novoice';
      for (const c of [this.conns.get(this.active), ...this.conns.values()].filter(Boolean)) {
        const me = this.clients.get(k(c.id, c.clientId));
        if (!me) continue;
        members = [...this.clients.values()].filter((x) => x.conn === c.id && x.ch === me.ch)
          .sort((a, b) => a.nick.localeCompare(b.nick)).map(({ id, nick, talk }) => ({ id, nick, talk }));
        status = 'ok'; break;
      }
    }
    return { status, members, client: 'ts6' };
  }
}
module.exports = { TsClient };

