'use strict';
// TeamSpeak 3 ClientQuery adapter (local TCP, usually 127.0.0.1:25639).
const net = require('net');
const { EventEmitter } = require('events');

function decode(s) {
  return String(s || '').replace(/\\([\\/spnrtab])/g, (_m, c) => ({ s: ' ', p: '|', n: '\n', r: '\r', t: '\t', a: '\x07', b: '\b' }[c] ?? c));
}
function fields(s) {
  const out = {};
  for (const part of s.trim().split(/\s+/)) {
    const i = part.indexOf('=');
    if (i > 0) out[part.slice(0, i)] = decode(part.slice(i + 1));
  }
  return out;
}
function records(s) {
  return s.split(/(?<!\\)\|/).map(fields).filter((x) => Object.keys(x).length);
}

class Ts3Client extends EventEmitter {
  constructor(o) {
    super(); this.o = { port: 25639, retryMs: 4000, ...o }; this.stopped = true;
    this.phase = 'connecting'; this.clients = new Map(); this.channel = null; this.handler = null; this.commandQueue = Promise.resolve();
  }
  start() { this.stopped = false; this.connect(); }
  stop() { this.stopped = true; clearTimeout(this.timer); const p = this.pending; this.pending = null; if (p) { clearTimeout(p.timer); p.reject(new Error('Отключено')); } const s = this.sock; this.sock = null; if (s) s.destroy(); }
  reconnect() { if (!this.stopped) { this.stop(); this.start(); } }
  configure(port, key) { const changed = port !== this.o.port || key !== this.o.getKey(); this.o.port = port; this.o.setKey(key); if (changed && !this.stopped) { this.stop(); this.start(); } }
  state() {
    let status = this.phase, members = [];
    if (this.phase === 'online') {
      status = this.channel == null ? 'novoice' : 'ok';
      if (this.channel != null) members = [...this.clients.values()].filter((c) => c.channel === this.channel)
        .sort((a, b) => a.nick.localeCompare(b.nick)).map((c) => ({ id: c.id, nick: c.nick, talk: c.talk }));
    }
    return { status, members, client: 'ts3' };
  }
  emitState() { this.emit('state', this.state()); }
  connect() {
    clearTimeout(this.timer); this.clients.clear(); this.channel = null;
    if (this.phase !== 'nocon' && this.phase !== 'denied') { this.phase = 'connecting'; this.emitState(); }
    const sock = this.sock = net.createConnection({ host: '127.0.0.1', port: Number(this.o.port) });
    sock.setEncoding('utf8'); let buf = '', greeting = false;
    sock.on('connect', () => { this.phase = 'waiting'; this.emitState(); });
    sock.on('data', (chunk) => {
      buf += chunk;
      let i;
      while ((i = buf.indexOf('\n')) >= 0) {
        const line = buf.slice(0, i).replace(/^\r+|\r+$/g, ''); buf = buf.slice(i + 1);
        if (!greeting) {
          if (line.includes('selected schandlerid=')) {
            greeting = true; this.handler = fields(line).schandlerid || '1';
            this.bootstrap().then(() => { if (this.sock === sock) { this.phase = 'online'; this.emitState(); } }).catch((e) => { if (this.sock === sock) this.queryError(e); });
          }
          continue;
        }
        this.onLine(line);
      }
    });
    sock.on('error', () => {});
    sock.on('close', () => {
      if (this.sock !== sock) return;
      this.sock = null; const p = this.pending; this.pending = null; if (p) { clearTimeout(p.timer); p.reject(new Error('Соединение ClientQuery закрыто')); } this.clients.clear(); this.channel = null;
      this.phase = 'nocon'; this.emitState();
      if (!this.stopped) this.timer = setTimeout(() => this.connect(), this.o.retryMs);
    });
  }
  command(line, timeout = 5000) {
    const expectedSocket = this.sock;
    const run = () => this.sendCommand(line, timeout, expectedSocket);
    const result = this.commandQueue.then(run, run);
    this.commandQueue = result.catch(() => {});
    return result;
  }
  sendCommand(line, timeout, expectedSocket) {
    const sock = expectedSocket;
    if (!sock || sock !== this.sock || sock.destroyed) return Promise.reject(new Error('Соединение ClientQuery изменилось'));
    return new Promise((resolve, reject) => {
      const p = this.pending = { lines: [], resolve, reject, timer: setTimeout(() => { if (this.pending === p) { this.pending = null; reject(new Error('Таймаут ClientQuery')); } }, timeout) };
      sock.write(line + '\n');
    });
  }
  async bootstrap() {
    const key = this.o.getKey();
    if (key) await this.command('auth apikey=' + key.replace(/\\/g, '\\\\').replace(/\s/g, '\\s').replace(/\|/g, '\\p'));
    if (this.handler) await this.command('use schandlerid=' + this.handler);
    await this.command('clientnotifyregister schandlerid=0 event=notifytalkstatuschange');
    await this.command('clientnotifyregister schandlerid=0 event=notifyclientmoved');
    await this.command('clientnotifyregister schandlerid=0 event=notifyclientleftview');
    await this.command('clientnotifyregister schandlerid=0 event=notifycliententerview');
    await this.command('clientnotifyregister schandlerid=0 event=notifycurrentserverconnectionchanged');
    await this.refresh();
    this.phase = 'online';
  }
  onLine(line) {
    if (!line) return;
    if (/^notify\w+\s/.test(line)) { this.notification(line); return; }
    const p = this.pending; if (!p) return;
    if (/^error id=/.test(line)) {
      clearTimeout(p.timer); this.pending = null;
      const err = fields(line);
      if (err.id !== '0') { const e = new Error(decode(err.msg) || ('ClientQuery error ' + err.id)); e.code = Number(err.id); p.reject(e); }
      else p.resolve(p.lines.join('\n'));
    } else p.lines.push(line);
  }
  notification(line) {
    const i = line.indexOf(' '), name = i < 0 ? line : line.slice(0, i), p = fields(i < 0 ? '' : line.slice(i + 1));
    if (name === 'notifytalkstatuschange') {
      if (p.schandlerid && String(p.schandlerid) !== String(this.handler)) return;
      const c = this.clients.get(String(p.clid || p.clientid)); if (c) { c.talk = Number(p.status) > 0; this.emitState(); }
    } else if (name === 'notifycurrentserverconnectionchanged') {
      if (p.schandlerid) this.handler = String(p.schandlerid);
      if (this.handler) this.command('use schandlerid=' + this.handler).then(() => this.refresh()).catch((e) => this.queryError(e));
    } else if (['notifyclientmoved', 'notifyclientleftview', 'notifycliententerview'].includes(name)) {
      this.refresh().catch((e) => this.queryError(e));
    }
  }
  async refresh() {
    if (this.stopped || !this.sock) return;
    if (this.refreshing) { this.refreshAgain = true; return; }
    this.refreshing = true;
    try {
      const who = await this.command('whoami');
      const me = records(who)[0] || fields(who);
      const data = await this.command('clientlist -voice');
      const list = records(data).filter((x) => x.clid && x.client_type !== '1');
      // ClientQuery/ServerQuery builds use different names for whoami fields.
      const selfId = me.clid ?? me.client_id ?? me.clientid;
      const self = selfId == null ? null : list.find((x) => String(x.clid) === String(selfId));
      const whoChannel = me.cid ?? me.client_channel_id ?? me.clientchannelid;
      const currentChannel = self ? self.cid : (whoChannel && whoChannel !== '0' ? whoChannel : null), next = new Map();
      for (const x of list) {
        const old = this.clients.get(String(x.clid));
        next.set(String(x.clid), { id: Number(x.clid), nick: x.client_nickname || '?', channel: x.cid, talk: old ? old.talk : x.client_flag_talking === '1' });
      }
      this.clients = next; this.channel = currentChannel;
      this.phase = 'online'; this.emitState();
    } catch (e) {
      if (Number(e.code) === 1794) {
        this.clients.clear(); this.channel = null; this.phase = 'online'; this.emitState(); return;
      }
      throw e;
    } finally {
      this.refreshing = false;
      if (this.refreshAgain) { this.refreshAgain = false; if (!this.stopped) setTimeout(() => this.refresh().catch((e) => this.queryError(e)), 80); }
    }
  }
  queryError(e) {
    if (Number(e.code) === 1794) { this.phase = 'online'; this.clients.clear(); this.channel = null; this.emitState(); return; }
    this.emit('warn', e);
    if (/auth|apikey|permission|not allowed|not authorized|not logged in/i.test(e.message)) this.phase = 'denied';
    else { this.phase = 'online'; this.clients.clear(); this.channel = null; }
    this.emitState();
  }
}
module.exports = { Ts3Client };
